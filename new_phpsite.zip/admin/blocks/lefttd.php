<td width="182px" valign="top" class="left">
    <p class="title">Уроки</p>
    <div id="coolmenu">
    <a href="new_lesson.php">Добавить</a>
    <a href="edit_lesson.php">Редактировать</a>
    <a href="del_lesson.php">Удалить</a>
    </div>	

    <p class="title">Статьи</p>
    <div id="coolmenu">
    <a href="index.php">Добавить</a>
    <a href="articles.php">Редактировать</a>
    <a href="lessons.php">Удалить</a>
    </div>	

    <p class="title">Тексты</p>
    <div id="coolmenu">
    <a href="edit_text.php">Редактировать</a>
    </div>
</td>