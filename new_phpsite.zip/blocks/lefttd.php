<td width="182px" valign="top" class="left">
    <p class="title">Навигация</p>
    <div id="coolmenu">
    <a href="index.php">Главная</a>
    <a href="articles.php">Статьи</a>
    <a href="lessons.php">Уроки</a>
    <a href="contacts.php">О нас</a>
    </div>	
</td>